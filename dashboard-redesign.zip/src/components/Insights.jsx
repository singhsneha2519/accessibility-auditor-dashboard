import { FlaskConical } from 'lucide-react';
import { sampleInsights } from '../data/sampleInsights';

const SEVERITY_COLORS = {
  critical: '#d92d43',
  serious: '#c77700',
  moderate: '#2f6fdb',
  minor: '#2e8b57',
};

function Donut({ segments }) {
  const total = segments.reduce((sum, s) => sum + s.value, 0);
  let running = 0;
  const stops = segments
    .map((s) => {
      const start = running;
      running += (s.value / total) * 100;
      return `${SEVERITY_COLORS[s.level]} ${start}% ${running}%`;
    })
    .join(', ');

  const description = segments.map((s) => `${s.value} ${s.level}`).join(', ');

  return (
    <div className="donut-wrap">
      <div
        className="donut"
        style={{ background: `conic-gradient(${stops})` }}
        role="img"
        aria-label={`Violations by severity: ${description}`}
      >
        <div className="donut-hole">
          <strong>{total}</strong>
          <span>violations</span>
        </div>
      </div>
      <ul className="legend">
        {segments.map((s) => (
          <li key={s.level}>
            <span className="legend-dot" style={{ background: SEVERITY_COLORS[s.level] }} aria-hidden="true" />
            <span className="legend-name">{s.level}</span>
            <strong>{s.value}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Insights() {
  const { totals, topViolations, severity } = sampleInsights;
  const max = Math.max(...topViolations.map((v) => v.sites));

  const kpis = [
    { label: 'Sites scanned', value: totals.sitesScanned },
    { label: 'Scanned successfully', value: totals.successful },
    { label: 'Blocked sites', value: totals.blocked },
    { label: 'Violations found', value: totals.violations },
  ];

  return (
    <div className="page">
      <header className="page-head">
        <h1>Insights</h1>
        <p className="muted">Patterns across every government website we have scanned.</p>
      </header>

      <div className="banner" role="note">
        <FlaskConical size={20} aria-hidden="true" />
        <p>
          <strong>Sample data.</strong> These figures come from our 35-site pilot dataset and are
          fixed for now. They will switch to live output from the data science pipeline.
        </p>
      </div>

      <ul className="stats">
        {kpis.map((k) => (
          <li key={k.label} className="stat card">
            <span className="stat-value">{k.value}</span>
            <span className="stat-label">{k.label}</span>
          </li>
        ))}
      </ul>

      <div className="insight-grid">
        <section className="card chart-card" aria-labelledby="top-title">
          <h2 id="top-title">Most common problems</h2>
          <p className="muted">Number of sites, out of {totals.successful}, that have each issue.</p>
          <ol className="bars">
            {topViolations.map((v) => (
              <li key={v.id} className="bar-row">
                <div className="bar-label">
                  <span>{v.label}</span>
                  <code>{v.id}</code>
                </div>
                <div className="bar-track" aria-hidden="true">
                  <div className="bar-fill" style={{ width: `${(v.sites / max) * 100}%` }} />
                </div>
                <div className="bar-value">
                  <strong>{v.sites}</strong>
                  <span>{Math.round((v.sites / totals.successful) * 100)}%</span>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <div className="insight-side">
          <section className="card chart-card" aria-labelledby="sev-title">
            <h2 id="sev-title">How serious the problems are</h2>
            <p className="muted">All violations found, by severity.</p>
            <Donut segments={severity} />
          </section>

          <section className="card placeholder" aria-labelledby="soon-title">
            <h2 id="soon-title">Coming from data science</h2>
            <ul>
              <li>Municipal, state and central sites compared</li>
              <li>How a site’s results change between scans</li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}

export default Insights;
