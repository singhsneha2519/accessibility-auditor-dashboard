// STATIC SAMPLE DATA
// These numbers come from our pilot dataset (35 government websites).
// When the data science pipeline is ready, replace this file's contents
// (or fetch the same shape from the DS API) and the Insights page updates itself.

export const sampleInsights = {
  totals: {
    sitesScanned: 35,
    successful: 33,
    blocked: 2,
    violations: 139,
  },

  // How many of the 33 successfully scanned sites had each issue
  topViolations: [
    { id: 'link-name', label: 'Links with no readable text', sites: 18 },
    { id: 'color-contrast', label: 'Text too faint to read', sites: 17 },
    { id: 'target-size', label: 'Touch targets too small', sites: 16 },
    { id: 'frame-title', label: 'Embedded frames without a title', sites: 12 },
    { id: 'image-alt', label: 'Images without alt text', sites: 11 },
    { id: 'aria-required-children', label: 'Broken ARIA structure', sites: 9 },
    { id: 'button-name', label: 'Buttons without a name', sites: 7 },
    { id: 'marquee', label: 'Scrolling marquee text', sites: 7 },
    { id: 'html-has-lang', label: 'Page language not declared', sites: 7 },
    { id: 'meta-viewport', label: 'Zooming disabled on mobile', sites: 5 },
  ],

  // Every violation found, grouped by how serious it is
  severity: [
    { level: 'critical', value: 39 },
    { level: 'serious', value: 95 },
    { level: 'moderate', value: 5 },
  ],
};
